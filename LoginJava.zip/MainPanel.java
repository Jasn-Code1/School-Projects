import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPanel extends JPanel {
    JPanel buttonPanel;
    JButton exitButton;
    JButton loginButton;
    public MainPanel(){
        this.setPreferredSize(new Dimension(600,600));
        this.setLayout(new FlowLayout());
        //this.setBackground(Color.lightGray);
        LoginPanel loginPanel = new LoginPanel();

        UsernamePanel usernamePanel = new UsernamePanel();

        PasswordPanel passwordPanel = new PasswordPanel();

        ButtonPanel buttonPanel = new ButtonPanel();

        this.add(loginPanel);
        this.add(usernamePanel);
        this.add(passwordPanel);
        this.add(buttonPanel);
    }
    private static class LoginPanel extends JPanel{
        JLabel loginText;
        LoginPanel(){
            this.setPreferredSize(new Dimension(500,200));
            this.setLayout(new FlowLayout());

            loginText = new JLabel();
            loginText.setText("Login");
            loginText.setFont(new Font("Mono Font", Font.BOLD, 35));
            loginText.setVerticalTextPosition(JLabel.CENTER);
            loginText.setHorizontalAlignment(JLabel.CENTER);
            loginText.setPreferredSize(new Dimension(500,200));

            this.add(loginText);
        }
    }
    private static class UsernamePanel extends JPanel{
        JLabel usernameText;
        JTextField usernameInput;
        public UsernamePanel(){
            this.setPreferredSize(new Dimension(500,50));
            this.setLayout(new FlowLayout());

            usernameText = new JLabel();
            usernameText.setText("Username");
            usernameText.setFont(new Font("Mono Font", Font.BOLD, 20));
            usernameText.setVerticalTextPosition(JLabel.TOP);
            usernameText.setHorizontalAlignment(JLabel.CENTER);
            usernameText.setPreferredSize(new Dimension(100,30));

            usernameInput = new JTextField();
            usernameInput.setFont(new Font("Mono Font", Font.BOLD, 20));
            usernameInput.setPreferredSize(new Dimension(300,30));

            this.add(usernameText);
            this.add(usernameInput);
        }
    }
    private static class PasswordPanel extends JPanel{
        JLabel passwordText;
        JPasswordField passwordInput;
        public PasswordPanel(){
            this.setPreferredSize(new Dimension(500,50));
            this.setLayout(new FlowLayout());

            passwordText = new JLabel();
            passwordText.setText("Password");
            passwordText.setFont(new Font("Mono Font", Font.BOLD, 20));
            passwordText.setVerticalTextPosition(JLabel.TOP);
            passwordText.setHorizontalAlignment(JLabel.CENTER);
            passwordText.setPreferredSize(new Dimension(100,30));

            passwordInput = new JPasswordField();
            passwordInput.setFont(new Font("Mono Font", Font.BOLD, 20));
            passwordInput.setPreferredSize(new Dimension(300,30));

            this.add(passwordText);
            this.add(passwordInput);
        }
    }
    private static class ButtonPanel extends JPanel implements ActionListener {
        JButton exitButton;
        JButton loginButton;
        public ButtonPanel(){
            this.setPreferredSize(new Dimension(500,80));
            this.setLayout(new FlowLayout());

            exitButton = new JButton();
            exitButton.setPreferredSize(new Dimension(200,50));
            exitButton.setText("Exit");
            exitButton.setBackground(new Color(255,100,100));
            exitButton.setVerticalTextPosition(JLabel.TOP);
            exitButton.setHorizontalAlignment(JLabel.CENTER);
            exitButton.setFont(new Font("Mono Font", Font.BOLD, 20));
            exitButton.setFocusable(false);
            exitButton.addActionListener(this);

            loginButton = new JButton();
            loginButton.setPreferredSize(new Dimension(200,50));
            loginButton.setText("Login");
            loginButton.setBackground(new Color(100,255,100));
            loginButton.setVerticalTextPosition(JLabel.TOP);
            loginButton.setHorizontalAlignment(JLabel.CENTER);
            loginButton.setFont(new Font("Mono Font", Font.BOLD, 20));
            loginButton.setFocusable(false);

            this.add(exitButton);
            this.add(loginButton);
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource()==exitButton){
                System.exit(0);
            }
            if (e.getSource()==loginButton){
                
            }
        }
    }
}
