import javax.swing.*;

public class MyFrame extends JFrame {
    public MyFrame(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MainPanel mainPanel = new MainPanel();

        this.add(mainPanel);
        this.pack();
        this.setVisible(true);
    }
}
