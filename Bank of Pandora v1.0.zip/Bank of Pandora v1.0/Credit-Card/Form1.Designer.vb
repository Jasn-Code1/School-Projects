﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Card_bg = New Panel()
        Card_bg1 = New Panel()
        Choice = New TextBox()
        Label5 = New Label()
        choices2 = New Label()
        choices1 = New Label()
        Pandora1 = New Label()
        user_lbl = New Label()
        Login_btn = New Button()
        Exit_btn = New Button()
        Card = New Panel()
        Pin_no = New TextBox()
        Card_no = New TextBox()
        Label2 = New Label()
        Label1 = New Label()
        Pandora = New Label()
        Welcome = New Label()
        Timer1 = New Timer(components)
        Panel5_1 = New Panel()
        Panel6_1 = New Panel()
        Panel7_1 = New Panel()
        Panel8_1 = New Panel()
        Panel3_1 = New Panel()
        Panel4_1 = New Panel()
        Panel2_1 = New Panel()
        Panel1_1 = New Panel()
        Panel5 = New Panel()
        Panel6 = New Panel()
        Panel7 = New Panel()
        Panel8 = New Panel()
        Panel3 = New Panel()
        Panel4 = New Panel()
        Panel2 = New Panel()
        Panel1 = New Panel()
        Timer2 = New Timer(components)
        Timer3 = New Timer(components)
        Timer4 = New Timer(components)
        Card_bg.SuspendLayout()
        Card_bg1.SuspendLayout()
        Card.SuspendLayout()
        SuspendLayout()
        ' 
        ' Card_bg
        ' 
        Card_bg.BackColor = Color.Black
        Card_bg.Controls.Add(Card_bg1)
        Card_bg.Controls.Add(Login_btn)
        Card_bg.Controls.Add(Exit_btn)
        Card_bg.Controls.Add(Card)
        Card_bg.Controls.Add(Pandora)
        Card_bg.Controls.Add(Welcome)
        Card_bg.Location = New Point(0, 0)
        Card_bg.Name = "Card_bg"
        Card_bg.Size = New Size(600, 600)
        Card_bg.TabIndex = 0
        ' 
        ' Card_bg1
        ' 
        Card_bg1.BackColor = Color.Black
        Card_bg1.Controls.Add(Choice)
        Card_bg1.Controls.Add(Label5)
        Card_bg1.Controls.Add(choices2)
        Card_bg1.Controls.Add(choices1)
        Card_bg1.Controls.Add(Pandora1)
        Card_bg1.Controls.Add(user_lbl)
        Card_bg1.Location = New Point(0, 300)
        Card_bg1.Name = "Card_bg1"
        Card_bg1.Size = New Size(600, 300)
        Card_bg1.TabIndex = 6
        ' 
        ' Choice
        ' 
        Choice.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Choice.Location = New Point(357, 244)
        Choice.Name = "Choice"
        Choice.Size = New Size(125, 33)
        Choice.TabIndex = 6
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Label5.Location = New Point(91, 238)
        Label5.Name = "Label5"
        Label5.Size = New Size(267, 40)
        Label5.TabIndex = 5
        Label5.Text = "Enter Your Choice:"
        ' 
        ' choices2
        ' 
        choices2.AutoSize = True
        choices2.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        choices2.Location = New Point(351, 87)
        choices2.Name = "choices2"
        choices2.Size = New Size(165, 120)
        choices2.TabIndex = 4
        choices2.Text = "2 Withdrawal" & vbCrLf & "4 Fund Transfer" & vbCrLf & "6 Change Pin" & vbCrLf & "8 Logout"
        ' 
        ' choices1
        ' 
        choices1.AutoSize = True
        choices1.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        choices1.Location = New Point(91, 87)
        choices1.Name = "choices1"
        choices1.Size = New Size(188, 120)
        choices1.TabIndex = 3
        choices1.Text = "1 Diposit" & vbCrLf & "3 Balance" & vbCrLf & "5 Mini Statement" & vbCrLf & "7 Last Transaction"
        ' 
        ' Pandora1
        ' 
        Pandora1.AutoSize = True
        Pandora1.BackColor = Color.Transparent
        Pandora1.Font = New Font("Sitka Small", 18F, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Pandora1.ForeColor = Color.Lime
        Pandora1.Location = New Point(175, 8)
        Pandora1.Name = "Pandora1"
        Pandora1.Size = New Size(259, 35)
        Pandora1.TabIndex = 1
        Pandora1.Text = "BANK OF PANDORA"
        ' 
        ' user_lbl
        ' 
        user_lbl.BackColor = Color.Transparent
        user_lbl.Font = New Font("Sitka Small", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        user_lbl.ForeColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        user_lbl.Location = New Point(175, 39)
        user_lbl.Name = "user_lbl"
        user_lbl.RightToLeft = RightToLeft.No
        user_lbl.Size = New Size(259, 35)
        user_lbl.TabIndex = 2
        user_lbl.Text = "user: "
        user_lbl.TextAlign = ContentAlignment.TopCenter
        ' 
        ' Login_btn
        ' 
        Login_btn.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Login_btn.Cursor = Cursors.Hand
        Login_btn.FlatStyle = FlatStyle.Flat
        Login_btn.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Login_btn.ForeColor = Color.Black
        Login_btn.Location = New Point(388, 237)
        Login_btn.Name = "Login_btn"
        Login_btn.Size = New Size(77, 40)
        Login_btn.TabIndex = 5
        Login_btn.Text = "Login"
        Login_btn.UseVisualStyleBackColor = False
        ' 
        ' Exit_btn
        ' 
        Exit_btn.BackColor = Color.Red
        Exit_btn.Cursor = Cursors.Hand
        Exit_btn.FlatStyle = FlatStyle.Flat
        Exit_btn.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Exit_btn.ForeColor = Color.Lime
        Exit_btn.Location = New Point(471, 237)
        Exit_btn.Name = "Exit_btn"
        Exit_btn.Size = New Size(77, 40)
        Exit_btn.TabIndex = 4
        Exit_btn.Text = "Exit"
        Exit_btn.UseVisualStyleBackColor = False
        ' 
        ' Card
        ' 
        Card.Controls.Add(Pin_no)
        Card.Controls.Add(Card_no)
        Card.Controls.Add(Label2)
        Card.Controls.Add(Label1)
        Card.Location = New Point(52, 90)
        Card.Name = "Card"
        Card.Size = New Size(496, 125)
        Card.TabIndex = 3
        ' 
        ' Pin_no
        ' 
        Pin_no.Cursor = Cursors.Hand
        Pin_no.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Pin_no.Location = New Point(256, 79)
        Pin_no.Name = "Pin_no"
        Pin_no.Size = New Size(213, 23)
        Pin_no.TabIndex = 5
        ' 
        ' Card_no
        ' 
        Card_no.Cursor = Cursors.Hand
        Card_no.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Card_no.Location = New Point(256, 30)
        Card_no.Name = "Card_no"
        Card_no.Size = New Size(213, 23)
        Card_no.TabIndex = 4
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(128), CByte(128), CByte(255))
        Label2.Location = New Point(71, 70)
        Label2.Name = "Label2"
        Label2.Size = New Size(179, 32)
        Label2.TabIndex = 3
        Label2.Text = "Enter your pin"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.FromArgb(CByte(128), CByte(128), CByte(255))
        Label1.Location = New Point(21, 21)
        Label1.Name = "Label1"
        Label1.Size = New Size(229, 32)
        Label1.TabIndex = 2
        Label1.Text = "Enter your card no"
        ' 
        ' Pandora
        ' 
        Pandora.AutoSize = True
        Pandora.BackColor = Color.Transparent
        Pandora.Font = New Font("Sitka Small", 18F, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline, GraphicsUnit.Point, CByte(0))
        Pandora.ForeColor = Color.Lime
        Pandora.Location = New Point(175, 41)
        Pandora.Name = "Pandora"
        Pandora.Size = New Size(259, 35)
        Pandora.TabIndex = 1
        Pandora.Text = "BANK OF PANDORA"
        ' 
        ' Welcome
        ' 
        Welcome.AutoSize = True
        Welcome.BackColor = Color.Transparent
        Welcome.Font = New Font("Segoe UI Black", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Welcome.ForeColor = Color.Blue
        Welcome.Location = New Point(215, 12)
        Welcome.Name = "Welcome"
        Welcome.Size = New Size(175, 32)
        Welcome.TabIndex = 0
        Welcome.Text = "WELCOME TO"
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 50
        ' 
        ' Panel5_1
        ' 
        Panel5_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel5_1.Enabled = False
        Panel5_1.Location = New Point(388, -65)
        Panel5_1.Name = "Panel5_1"
        Panel5_1.Size = New Size(12, 12)
        Panel5_1.TabIndex = 31
        ' 
        ' Panel6_1
        ' 
        Panel6_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel6_1.Enabled = False
        Panel6_1.Location = New Point(362, -65)
        Panel6_1.Name = "Panel6_1"
        Panel6_1.Size = New Size(10, 10)
        Panel6_1.TabIndex = 30
        ' 
        ' Panel7_1
        ' 
        Panel7_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel7_1.Enabled = False
        Panel7_1.Location = New Point(336, -65)
        Panel7_1.Name = "Panel7_1"
        Panel7_1.Size = New Size(8, 8)
        Panel7_1.TabIndex = 29
        ' 
        ' Panel8_1
        ' 
        Panel8_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel8_1.Enabled = False
        Panel8_1.Location = New Point(310, -65)
        Panel8_1.Name = "Panel8_1"
        Panel8_1.Size = New Size(6, 6)
        Panel8_1.TabIndex = 28
        ' 
        ' Panel3_1
        ' 
        Panel3_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel3_1.Enabled = False
        Panel3_1.Location = New Point(457, -66)
        Panel3_1.Name = "Panel3_1"
        Panel3_1.Size = New Size(16, 16)
        Panel3_1.TabIndex = 27
        ' 
        ' Panel4_1
        ' 
        Panel4_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel4_1.Enabled = False
        Panel4_1.Location = New Point(479, -66)
        Panel4_1.Name = "Panel4_1"
        Panel4_1.Size = New Size(14, 14)
        Panel4_1.TabIndex = 26
        ' 
        ' Panel2_1
        ' 
        Panel2_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel2_1.Enabled = False
        Panel2_1.Location = New Point(433, -66)
        Panel2_1.Name = "Panel2_1"
        Panel2_1.Size = New Size(18, 18)
        Panel2_1.TabIndex = 25
        ' 
        ' Panel1_1
        ' 
        Panel1_1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel1_1.Enabled = False
        Panel1_1.Location = New Point(407, -66)
        Panel1_1.Name = "Panel1_1"
        Panel1_1.Size = New Size(20, 20)
        Panel1_1.TabIndex = 24
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel5.Enabled = False
        Panel5.Location = New Point(386, -85)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(12, 12)
        Panel5.TabIndex = 23
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel6.Enabled = False
        Panel6.Location = New Point(360, -85)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(10, 10)
        Panel6.TabIndex = 22
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel7.Enabled = False
        Panel7.Location = New Point(334, -85)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(8, 8)
        Panel7.TabIndex = 21
        ' 
        ' Panel8
        ' 
        Panel8.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel8.Enabled = False
        Panel8.Location = New Point(308, -85)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(6, 6)
        Panel8.TabIndex = 20
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel3.Enabled = False
        Panel3.Location = New Point(454, -89)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(16, 16)
        Panel3.TabIndex = 19
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel4.Enabled = False
        Panel4.Location = New Point(476, -89)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(14, 14)
        Panel4.TabIndex = 18
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel2.Enabled = False
        Panel2.Location = New Point(430, -89)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(18, 18)
        Panel2.TabIndex = 17
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Panel1.Enabled = False
        Panel1.Location = New Point(404, -89)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(20, 20)
        Panel1.TabIndex = 16
        ' 
        ' Timer2
        ' 
        Timer2.Enabled = True
        Timer2.Interval = 1
        ' 
        ' Timer3
        ' 
        Timer3.Enabled = True
        Timer3.Interval = 1
        ' 
        ' Timer4
        ' 
        Timer4.Interval = 5
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(598, 298)
        ControlBox = False
        Controls.Add(Panel5_1)
        Controls.Add(Panel6_1)
        Controls.Add(Panel7_1)
        Controls.Add(Panel8_1)
        Controls.Add(Panel3_1)
        Controls.Add(Panel4_1)
        Controls.Add(Panel2_1)
        Controls.Add(Panel1_1)
        Controls.Add(Panel5)
        Controls.Add(Panel6)
        Controls.Add(Panel7)
        Controls.Add(Panel8)
        Controls.Add(Panel3)
        Controls.Add(Panel4)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(Card_bg)
        Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ForeColor = Color.Lime
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        Text = "__________________________________B__A__N__K____O__F____P__A__N__D__O__R__A_____________________________________________________"
        Card_bg.ResumeLayout(False)
        Card_bg.PerformLayout()
        Card_bg1.ResumeLayout(False)
        Card_bg1.PerformLayout()
        Card.ResumeLayout(False)
        Card.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Card_bg As Panel
    Friend WithEvents Welcome As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Pandora As Label
    Friend WithEvents Panel5_1 As Panel
    Friend WithEvents Panel6_1 As Panel
    Friend WithEvents Panel7_1 As Panel
    Friend WithEvents Panel8_1 As Panel
    Friend WithEvents Panel3_1 As Panel
    Friend WithEvents Panel4_1 As Panel
    Friend WithEvents Panel2_1 As Panel
    Friend WithEvents Panel1_1 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Card As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Card_no As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Pin_no As TextBox
    Friend WithEvents Exit_btn As Button
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Login_btn As Button
    Friend WithEvents Card_bg1 As Panel
    Friend WithEvents Pandora1 As Label
    Friend WithEvents user_lbl As Label
    Friend WithEvents Timer4 As Timer
    Friend WithEvents choices1 As Label
    Friend WithEvents choices2 As Label
    Friend WithEvents Choice As TextBox
    Friend WithEvents Label5 As Label

End Class
