﻿Public Class Form1
    Dim col As Color = Color.FromArgb(255, 0, 255, 255)
    Dim Bl As Integer = 255
    Dim Gr As Integer = 255
    Dim Re As Integer = 0
    Dim Bl_up As Boolean = False
    Dim Gr_up As Boolean = False
    Dim Re_up As Boolean = True

    Dim str As String = "WELCOME TO"
    Dim str1 As String = ""
    Dim str_i As Integer = -1
    Dim str2 As String = "BANK OF PANDORA"
    Dim str2_i As Integer = -1
    Dim str3 As String = ""
    Dim bal As Double = 0
    Dim page As String = "main"
    Dim ch1_str As String
    Dim ch2_str As String

    Dim pos As Point
    Dim pos1 As Point
    Dim pos2 As Point

    Dim siz As Size
    Dim siz1 As Size

    Dim info As List(Of List(Of String)) = New List(Of List(Of String))

    Private Sub Welcome_Click(sender As Object, e As EventArgs) Handles Welcome.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If str_i < str.Count() - 1 Then
            str_i += 1
            str1 += str.ElementAt(str_i)
            Welcome.Text = str1
        ElseIf str2_i < str2.Count() - 1 Then
            str2_i += 1
            str3 += str2.ElementAt(str2_i)
            Pandora.Text = str3
        Else
            Timer1.Enabled = False
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Pandora.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Welcome.Text = ""
        Pandora.Text = ""
        pos = New Point(Card.Location.X, Card.Location.Y)
        siz = Login_btn.Size
        Card.Location = New Point(Card.Location.X, 500)
        Login_btn.Size = New Size(0, Login_btn.Size.Height)
        Exit_btn.Size = New Size(0, Login_btn.Size.Height)
        ch1_str = choices1.Text
        ch2_str = choices2.Text

        Dim ident As List(Of String) = New List(Of String)
        ident.Add("Harvie Pogi")
        ident.Add("12345")
        ident.Add("6789")
        ident.Add("150.25")
        info.Add(ident)

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim pos As Point = Me.PointToClient(MousePosition)
        Panel8.Location = New Point(Panel8_1.Location.X, Panel8_1.Location.Y)
        Panel8_1.Location = New Point(Panel7.Location.X + 1, Panel7.Location.Y + 1)
        Panel7.Location = New Point(Panel7_1.Location.X, Panel7_1.Location.Y)
        Panel7_1.Location = New Point(Panel6.Location.X + 1, Panel6.Location.Y + 1)
        Panel6.Location = New Point(Panel6_1.Location.X, Panel6_1.Location.Y)
        Panel6_1.Location = New Point(Panel5.Location.X + 1, Panel5.Location.Y + 1)
        Panel5.Location = New Point(Panel5_1.Location.X, Panel5_1.Location.Y)
        Panel5_1.Location = New Point(Panel4.Location.X + 1, Panel4.Location.Y + 1)
        Panel4.Location = New Point(Panel4_1.Location.X, Panel4_1.Location.Y)
        Panel4_1.Location = New Point(Panel3.Location.X + 1, Panel3.Location.Y + 1)
        Panel3.Location = New Point(Panel3_1.Location.X, Panel3_1.Location.Y)
        Panel3_1.Location = New Point(Panel2.Location.X + 1, Panel2.Location.Y + 1)
        Panel2.Location = New Point(Panel2_1.Location.X, Panel2_1.Location.Y)
        Panel2_1.Location = New Point(Panel1.Location.X + 1, Panel1.Location.Y + 1)
        Panel1.Location = New Point(Panel1_1.Location.X, Panel1_1.Location.Y)
        Panel1_1.Location = New Point(pos.X - 10, pos.Y - 10)
        Panel8.BackColor = Panel8_1.BackColor
        Panel8_1.BackColor = Panel7.BackColor
        Panel7.BackColor = Panel7_1.BackColor
        Panel7_1.BackColor = Panel6.BackColor
        Panel6.BackColor = Panel6_1.BackColor
        Panel6_1.BackColor = Panel5.BackColor
        Panel5.BackColor = Panel5_1.BackColor
        Panel5_1.BackColor = Panel4.BackColor
        Panel4.BackColor = Panel4_1.BackColor
        Panel4_1.BackColor = Panel3.BackColor
        Panel3.BackColor = Panel3_1.BackColor
        Panel3_1.BackColor = Panel2.BackColor
        Panel2.BackColor = Panel2_1.BackColor
        Panel2_1.BackColor = Panel1.BackColor
        Panel1.BackColor = Panel1_1.BackColor
        Panel1_1.BackColor = col
        If (Bl > 0 + 20) And (Bl_up = False) Then
            Bl -= 20
        ElseIf (Bl < 255 - 20) And Bl_up Then
            Bl += 20
        Else
            If Bl_up Then
                Bl = 255
                Bl_up = False
            Else
                Bl = 0
                Bl_up = True
            End If
        End If
        If (Gr > 0 + 18) And (Not Gr_up) Then
            Gr -= 18
        ElseIf (Gr < 255 - 18) And Gr_up Then
            Gr += 18
        Else
            If Gr_up Then
                Gr = 255
                Gr_up = False
            Else
                Gr = 0
                Gr_up = True
            End If
        End If
        If (Re > 0 + 16) And (Re_up = False) Then
            Re -= 16
        ElseIf (Re < 255 - 16) And Re_up Then
            Re += 16
        Else
            If Re_up Then
                Re = 255
                Re_up = False
            Else
                Re = 0
                Re_up = True
            End If
        End If
        col = Color.FromArgb(255, Re, Gr, Bl)
    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If Card.Location.Y - 3 > pos.Y Then
            Card.Location = New Point(Card.Location.X, Card.Location.Y - 3)
        ElseIf Login_btn.Size.Width + 4 < siz.Width Then
            Card.Location = pos
            Login_btn.Size = New Size(Login_btn.Width + 4, Login_btn.Height)
        ElseIf Exit_btn.Size.Width + 4 < siz.Width Then
            Login_btn.Size = siz
            Exit_btn.Size = New Size(Exit_btn.Size.Width + 4, Exit_btn.Size.Height)
        Else
            Exit_btn.Size = siz
            Timer3.Enabled = False
        End If
    End Sub

    Private Sub Exit_btn_Click(sender As Object, e As EventArgs) Handles Exit_btn.Click
        Close()
    End Sub

    Private Sub Login_btn_Click(sender As Object, e As EventArgs) Handles Login_btn.Click
        If Card_no.Text = "" Then
            Dim msg As String = MsgBox("Card Number must be filled!", vbYes)
            Card_no.Select()
        ElseIf Pin_no.Text = "" Then
            Dim msg As String = MsgBox("Pin Number must be filled!", vbYes)
            Pin_no.Select()
        Else
            Dim isin = False
            For i = 0 To info.Count - 1
                If Card_no.Text = info(i)(1).ToString And Pin_no.Text = info(i)(2).ToString Then
                    isin = True
                    user_lbl.Text = "user: " + info(i)(0)
                    bal = Double.Parse(info(i)(3))
                    pos1 = user_lbl.Location
                    user_lbl.Location = New Point(user_lbl.Location.X, Pandora1.Location.Y)
                End If
            Next
            If isin Then
                Card_no.Text = ""
                Pin_no.Text = ""
                Card_bg1.Location = New Point(0, 0)
                Timer4.Enabled = True
            Else
                Dim msg As String = MsgBox("Wrong Card Number or Pin Number!", vbYes)
                Card_no.Text = ""
                Pin_no.Text = ""
                Card_no.Select()
            End If
        End If

    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        If user_lbl.Location.Y + 1 < pos1.Y Then
            user_lbl.Location = New Point(user_lbl.Location.X, user_lbl.Location.Y + 1)
        Else
            user_lbl.Location = pos1
            Timer4.Enabled = False
        End If
    End Sub

    Private Sub Choice_TextChanged(sender As Object, e As EventArgs) Handles Choice.TextChanged
        If page = "main" Then
            If Choice.Text = "8" Then
                Card_bg1.Location = New Point(0, 300)
            ElseIf Choice.Text = "3" Then
                page = "3"
                choices1.Text = "Balance: $" + bal.ToString + System.Environment.NewLine + "1 Back" + System.Environment.NewLine + "2 Logout"
                choices2.Text = ""
            End If
        ElseIf page = "3" Then
            If Choice.Text = "1" Then
                page = "main"
                choices1.Text = ch1_str
                choices2.Text = ch2_str
            ElseIf Choice.Text = "2" Then
                page = "main"
                choices1.Text = ch1_str
                choices2.Text = ch2_str
                Card_bg1.Location = New Point(0, 300)
            End If
        End If
        Choice.Text = ""
    End Sub
End Class
