﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Panel1 = New Panel()
        User_name = New Label()
        Panel3 = New Panel()
        Panel4 = New Panel()
        Button2 = New Button()
        Button1 = New Button()
        Pin_No = New TextBox()
        Card_No = New TextBox()
        Label3 = New Label()
        Panel2 = New Panel()
        Panel5 = New Panel()
        Label2 = New Label()
        Label1 = New Label()
        Timer1 = New Timer(components)
        DateTimePicker1 = New DateTimePicker()
        Panel1.SuspendLayout()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        Panel2.SuspendLayout()
        Panel5.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(255))
        Panel1.Controls.Add(DateTimePicker1)
        Panel1.Controls.Add(User_name)
        Panel1.Controls.Add(Panel3)
        Panel1.Controls.Add(Panel2)
        Panel1.Location = New Point(12, 12)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(776, 426)
        Panel1.TabIndex = 0
        ' 
        ' User_name
        ' 
        User_name.BackColor = Color.Transparent
        User_name.Font = New Font("Algerian", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        User_name.ForeColor = Color.Black
        User_name.Location = New Point(758, 8)
        User_name.Name = "User_name"
        User_name.Size = New Size(10, 10)
        User_name.TabIndex = 6
        User_name.Text = " "
        User_name.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.Gray
        Panel3.Controls.Add(Panel4)
        Panel3.Location = New Point(37, 120)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(697, 270)
        Panel3.TabIndex = 1
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        Panel4.Controls.Add(Button2)
        Panel4.Controls.Add(Button1)
        Panel4.Controls.Add(Pin_No)
        Panel4.Controls.Add(Card_No)
        Panel4.Controls.Add(Label3)
        Panel4.Location = New Point(13, 11)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(670, 249)
        Panel4.TabIndex = 2
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(128))
        Button2.Font = New Font("Algerian", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(545, 188)
        Button2.Name = "Button2"
        Button2.Size = New Size(104, 40)
        Button2.TabIndex = 4
        Button2.Text = "LOGIN"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Red
        Button1.Font = New Font("Algerian", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(435, 188)
        Button1.Name = "Button1"
        Button1.Size = New Size(104, 40)
        Button1.TabIndex = 3
        Button1.Text = "EXIT"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Pin_No
        ' 
        Pin_No.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Pin_No.Location = New Point(302, 108)
        Pin_No.Name = "Pin_No"
        Pin_No.Size = New Size(347, 29)
        Pin_No.TabIndex = 2
        ' 
        ' Card_No
        ' 
        Card_No.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Card_No.Location = New Point(302, 59)
        Card_No.Name = "Card_No"
        Card_No.Size = New Size(347, 29)
        Card_No.TabIndex = 1
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Algerian", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(37, 59)
        Label3.Name = "Label3"
        Label3.Size = New Size(259, 78)
        Label3.TabIndex = 0
        Label3.Text = "ENTER YOUR CARD NO:" & vbCrLf & vbCrLf & "    ENTER YOUR PIN NO:"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.Cyan
        Panel2.Controls.Add(Panel5)
        Panel2.Location = New Point(255, 16)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(284, 81)
        Panel2.TabIndex = 0
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        Panel5.Controls.Add(Label2)
        Panel5.Controls.Add(Label1)
        Panel5.Location = New Point(9, 6)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(265, 68)
        Panel5.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Algerian", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(0), CByte(0), CByte(192))
        Label2.Location = New Point(24, 34)
        Label2.Name = "Label2"
        Label2.Size = New Size(224, 26)
        Label2.TabIndex = 1
        Label2.Text = "Bank of Pandora"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Algerian", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Maroon
        Label1.Location = New Point(60, 8)
        Label1.Name = "Label1"
        Label1.Size = New Size(156, 26)
        Label1.TabIndex = 0
        Label1.Text = "Welcome to"
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 1
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Enabled = False
        DateTimePicker1.Location = New Point(3, 4)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(200, 23)
        DateTimePicker1.TabIndex = 7
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Gray
        ClientSize = New Size(800, 450)
        Controls.Add(Panel1)
        Name = "Form1"
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Pin_No As TextBox
    Friend WithEvents Card_No As TextBox
    Friend WithEvents User_name As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker

End Class
