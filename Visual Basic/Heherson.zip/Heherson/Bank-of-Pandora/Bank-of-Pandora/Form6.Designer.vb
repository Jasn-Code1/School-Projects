﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        User_name = New Label()
        Label4 = New Label()
        Label2 = New Label()
        Choice = New TextBox()
        Panel2 = New Panel()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label3 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(255))
        Panel1.Controls.Add(User_name)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(Choice)
        Panel1.Controls.Add(Panel2)
        Panel1.Location = New Point(12, 12)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(776, 426)
        Panel1.TabIndex = 3
        ' 
        ' User_name
        ' 
        User_name.BackColor = Color.Transparent
        User_name.Font = New Font("Algerian", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        User_name.ForeColor = Color.Black
        User_name.Location = New Point(756, 10)
        User_name.Name = "User_name"
        User_name.Size = New Size(10, 10)
        User_name.TabIndex = 6
        User_name.Text = " "
        User_name.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label4
        ' 
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Algerian", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.Black
        Label4.Location = New Point(86, 30)
        Label4.Name = "Label4"
        Label4.Size = New Size(602, 30)
        Label4.TabIndex = 4
        Label4.Text = "USER: "
        Label4.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Algerian", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.Black
        Label2.Location = New Point(95, 345)
        Label2.Name = "Label2"
        Label2.Size = New Size(282, 30)
        Label2.TabIndex = 3
        Label2.Text = "ENTER YOUR CHOICE: "
        ' 
        ' Choice
        ' 
        Choice.BackColor = SystemColors.Window
        Choice.Font = New Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Choice.Location = New Point(393, 335)
        Choice.Name = "Choice"
        Choice.Size = New Size(295, 50)
        Choice.TabIndex = 3
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        Panel2.Controls.Add(TextBox2)
        Panel2.Controls.Add(TextBox1)
        Panel2.Controls.Add(Label3)
        Panel2.Location = New Point(86, 83)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(602, 217)
        Panel2.TabIndex = 2
        ' 
        ' TextBox2
        ' 
        TextBox2.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox2.Location = New Point(239, 70)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(345, 29)
        TextBox2.TabIndex = 3
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(239, 18)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(345, 29)
        TextBox1.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Algerian", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(17, 18)
        Label3.Name = "Label3"
        Label3.Size = New Size(210, 182)
        Label3.TabIndex = 1
        Label3.Text = "TARGET USER NO:" & vbCrLf & vbCrLf & "      FUND AMOUNT:" & vbCrLf & vbCrLf & "1. CONFIRM" & vbCrLf & vbCrLf & "2. BACK"
        ' 
        ' Form6
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Gray
        ClientSize = New Size(800, 450)
        Controls.Add(Panel1)
        Name = "Form6"
        Text = "Form6"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents User_name As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Choice As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label3 As Label
End Class
