﻿Public Class Form3
    Dim user_pin As String
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Choice_TextChanged(sender As Object, e As EventArgs) Handles Choice.TextChanged
        Dim num As Double
        Double.TryParse(Choice.Text, num)
        If num = 1 Then
            If TextBox1.Text = user_pin Then
                If Not (TextBox2.Text = "") Or Not (TextBox2.Text = " ") Then
                    If User_name.Text = "Heherson" Then
                        My.Computer.FileSystem.WriteAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user1_pin.txt", TextBox2.Text, False)
                        User_name.Text = ""
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        Me.Visible = False
                        Form2.Show()
                    ElseIf User_name.Text = "Aljane" Then
                        My.Computer.FileSystem.WriteAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user2_pin.txt", TextBox2.Text, False)
                        User_name.Text = ""
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        Me.Visible = False
                        Form2.Show()
                    End If
                End If
            Else
                Dim warn As String = MsgBox("Your pin number doesn't match the pin you've enter", vbOKOnly)
                TextBox1.Text = ""
                TextBox1.Select()
            End If
        End If
        If num = 2 Then
            User_name.Text = ""
            TextBox1.Text = ""
            TextBox2.Text = ""
            Me.Visible = False
            Form2.Show()
        End If
        Choice.Text = ""
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        Label4.Text = "USER: " & User_name.Text
        If User_name.Text = "Heherson" Then
            user_pin = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user1_pin.txt")
        ElseIf User_name.Text = "Aljane" Then
            user_pin = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user2_pin.txt")
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class