﻿Public Class Form1
    Dim welcome_pos As Point
    Dim card_pos As Point
    Dim user1_no As String
    Dim user1_pin As String
    Dim user1_name As String
    Dim user1_cash As String
    Dim user2_no As String
    Dim user2_pin As String
    Dim user2_name As String
    Dim user2_cash As String
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim panel2_pos As Point = Panel2.Location
        Dim panel3_pos As Point = Panel3.Location
        If panel2_pos.Y <= welcome_pos.Y Then
            Panel2.Location = New Point(panel2_pos.X, panel2_pos.Y + 2)
        End If
        If panel3_pos.Y >= card_pos.Y Then
            Panel3.Location = New Point(panel3_pos.X, panel3_pos.Y - 2)
        End If
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        welcome_pos = Panel2.Location
        card_pos = Panel3.Location
        Panel2.Location = New Point(welcome_pos.X, -340)
        Panel3.Location = New Point(card_pos.X, 450)
        User_name.Text = " "
    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button1_Enter(sender As Object, e As EventArgs) Handles Button1.MouseEnter
        Button1.BackColor = Color.FromArgb(255, 255, 255, 255)
    End Sub

    Private Sub Button1_Leave(sender As Object, e As EventArgs) Handles Button1.MouseLeave
        Button1.BackColor = Color.FromArgb(255, 255, 0, 0)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (user1_no = Card_No.Text) Or (user2_no = Card_No.Text) Then
            If user1_no = Card_No.Text Then
                If user1_pin = Pin_No.Text Then
                    Form2.Show()
                    Form2.User_name.Text = user1_name
                    Me.Visible = False
                Else
                    Dim warn As String = MsgBox("Wrong pin number, Please try again...", vbOKOnly)
                    Pin_No.Text = ""
                    Pin_No.Select()
                End If
            End If
            If user2_no = Card_No.Text Then
                If user2_pin = Pin_No.Text Then
                    Form2.Show()
                    Form2.User_name.Text = user2_name
                    Me.Visible = False
                Else
                    Dim warn As String = MsgBox("Wrong pin number, Please try again...", vbOKOnly)
                    Pin_No.Text = ""
                    Pin_No.Select()
                End If
            End If
        Else
            Dim warn As String = MsgBox("Invalid card number, Please try again...", vbOKOnly)
            Card_No.Text = ""
            Card_No.Select()
        End If
    End Sub

    Private Sub Button2_Enter(sender As Object, e As EventArgs) Handles Button2.MouseEnter
        Button2.BackColor = Color.FromArgb(255, 255, 255, 255)
    End Sub

    Private Sub Button2_Leave(sender As Object, e As EventArgs) Handles Button2.MouseLeave
        Button2.BackColor = Color.FromArgb(255, 128, 255, 128)
    End Sub

    Private Sub Card_No_TextChanged(sender As Object, e As EventArgs) Handles Card_No.TextChanged

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        User_name.Text = " "
        user1_no = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user1_no.txt")
        user1_pin = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user1_pin.txt")
        user1_name = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user1_name.txt")
        user2_no = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user2_no.txt")
        user2_pin = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user2_pin.txt")
        user2_name = My.Computer.FileSystem.ReadAllText("C:\Users\DELL\Documents\vb net\Heherson\Bank-of-Pandora\user2_name.txt")
        Card_No.Text = ""
        Pin_No.Text = ""
    End Sub
End Class
