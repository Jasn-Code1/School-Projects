import math as m
import numpy as np
import pygame as pg
import Functions as fn
import pickle as pk
import time

pg.init()

class Surface:
    def __init__(self, size):
        self.surface = pg.surface.Surface(size, pg.SRCALPHA)
    def set_alpha(self, value):
        self.surface.set_alpha(value)
    def set_rect(self, where, position):
        self.rect = self.surface.get_rect(where = position)
    def fill(self, color):
        self.surface.fill(color)
    def set_colorkey(self, color):
        self.surface.set_colorkey(color)

class Button:
    def __init__(self, text, position, tan, pos, color):
        self.surface = pg.surface.Surface((181,41))
        self.surface.set_colorkey('black')
        self.polygon4 = [(-40/tan,0),(180,0),(180+40/tan,40),(0,40)]
        self.polygon5 = [(-40/tan+3,3),(180-9,3),(180+40/tan-3,37),(9,37)]
        pg.draw.polygon(self.surface, (255, 255, 255), self.polygon4)
        pg.draw.polygon(self.surface, (200, 180, 220), self.polygon5)
        self.surface.blit(fn.text(text, color, 40), (40,5))
        self.rect = self.surface.get_rect(topleft = np.add(pos, position))
    def set_colorkey(self, color):
        self.surface.set_colorkey(color)
    def collide(self, position):
        return self.rect.collidepoint(position)

class Card:
    def __init__(self, position, size, color, border):
        self.surfaces = [Surface((800,500))]
        for i in range(4):
            self.surfaces.append(Surface(size))
        self.rects = [self.surfaces[0].surface.get_rect(topleft = (0,0))]
        for i in range(1,4):
            self.rects.append(self.surfaces[i].surface.get_rect(center = position))
        rect = self.surfaces[1].surface.get_rect(topleft = (0,0))
        self.surfaces[0].fill((255, 225, 255))
        self.surfaces[1].set_colorkey('black')
        pg.draw.rect(self.surfaces[1].surface, color, rect, 0, border)

        self.alpha = 255
        self.back_alpha = 255
        self.polygon1 = [(5,5),
                        (round(size[0]*.8)-5,5),
                        (round(size[0]*.5)-5, round(size[1]*.5)),
                        (5, round(size[1]*.5))
                        ]
        self.polygon2 = [(round(size[0]*.80)+5,5),
                        (size[0]-5,5),
                        (np.subtract(size, (5,5))),
                        (round(size[0]*.20)+5,size[1]-5)
                        ]
        dif = np.subtract(self.polygon2[-1], self.polygon2[0])
        tan = dif[1]/dif[0]
        self.tan = tan
        self.polygon3 = [(round(size[0]*.5)-15, round(size[1]*.5)-10*tan),
                        (round(size[0]*.5)-165, round(size[1]*.5)-160*tan),
                        (-150, round(size[1]*.5)-160*tan),
                        (0, round(size[1]*.5)-10*tan)
        ]
        pg.draw.polygon(self.surfaces[2].surface, (67, 56, 120), self.polygon1)
        pg.draw.polygon(self.surfaces[3].surface, (126, 96, 191), self.polygon2)
        self.polygon3 = np.add(self.polygon3, (150,0))
        pg.draw.polygon(self.surfaces[4].surface, (155, 126, 189), self.polygon3)
        self.angles = [-90, 90, -180]
        self.coef = 0
        self.position = position
        self.size = size
        self.pos = (self.position[0]-self.size[0]/2-150, self.position[1]-self.size[1]/2)

        self.button = Button("Login", (140,150), self.tan, self.pos, (0, 100, 0))
        self.surfaces[4].surface.blit(self.button.surface, (140,150))

        self.button1 = Button("Exit", (85,200), self.tan, self.pos, (220, 0, 0))
        self.surfaces[4].surface.blit(self.button1.surface, (85,200))

        self.text = fn.text("Welcome to", (0, 255, 0), 30)
        self.text1 = fn.text("BANK of", (0, 0, 255), 55)
        self.text2 = fn.text("PANDORA", (0, 200, 255), 65)
        self.surfaces[3].surface.blit(self.text, (270,100))
        self.surfaces[3].surface.blit(self.text1, (230,130))
        self.surfaces[3].surface.blit(self.text2, (180,180))

        self.state = 0

        self.rects.append(self.surfaces[4].surface.get_rect(topleft = np.add(self.pos, (-600, -600*self.tan))))

        self.textbox = pg.surface.Surface((280,40))
        self.textbox1 = pg.surface.Surface((230,40))
        self.textbox.fill('green')
        self.textbox1.fill('gray')
        self.textrect = self.textbox.get_rect(topleft = np.add(np.subtract(position, np.divide(size, 2)), (10,10)))
        self.textrect1 = self.textbox1.get_rect(topleft = np.add(np.subtract(position, np.divide(size, 2)), (10,55)))
        self.surfaces[2].surface.blit(self.textbox, (10,10))
        self.surfaces[2].surface.blit(self.textbox1, (10,55))
        self.tbtext = ''
        self.card_no = ''
        self.pin = ''
        self.tbtext1 = ''
        self.tbtext_surf = fn.text(self.tbtext, 'black', 30)
        self.tbtext_surf1 = fn.text(self.tbtext1, 'black', 30)
        self.surfaces[2].surface.blit(self.tbtext_surf, (15,16))
        self.surfaces[2].surface.blit(self.tbtext_surf1, (15,61))
        self.numsellect = False
        self.numsellect1 = False
        self.pinsellect = False
        self.pinsellect1 = False

        self.card_no_text = fn.text('Number -->', (0, 255, 0), 30)
        self.pin_no_text = fn.text('Pin -->', (0, 255, 0), 30)
        self.card_no_rect = self.card_no_text.get_rect(midright = (160,155))
        self.pin_no_rect = self.pin_no_text.get_rect(midright = (160,200))
        self.card_no_text.set_alpha(0)
        self.pin_no_text.set_alpha(0)
        self.text_alpha = 0
        self.text_alpha1 = 0

        self.database = []
        with open('database.db', 'rb') as f:
            self.database = pk.load(f)

        self.count = 1

    def update(self, fps):
        if self.coef + .5/fps < 1:
            self.coef += .5/fps
        else:
            self.coef = 1

        if self.state == 0:
            self.rects[2] = self.surfaces[1].surface.get_rect(center = fn.lerp2d((-200,-200), self.position, self.coef))
            self.rects[3] = self.surfaces[3].surface.get_rect(center = fn.lerp2d((1000,-200), self.position, self.coef))
        elif self.state == 1:
            if self.angles[2] + 90/fps < 0:
                self.angles[2] += 90/fps
            else:
                self.angles[2] = 0
            self.rects[4] = self.surfaces[4].surface.get_rect(topleft = fn.lerp2d(np.add(self.pos, (-600, -600*self.tan)), self.pos, self.coef))
            if self.surfaces[1].surface.get_alpha() + 255/fps < 255:
                self.surfaces[1].surface.set_alpha(self.surfaces[1].surface.get_alpha() + 255/fps)
            else:      
                self.surfaces[1].surface.set_alpha(255)
        elif self.state == 3:
            self.rects[2] = self.surfaces[1].surface.get_rect(center = fn.lerp2d((-200,-200), self.position, 1-self.coef))
            self.rects[3] = self.surfaces[3].surface.get_rect(center = fn.lerp2d((1000,-200), self.position, 1-self.coef))
            self.rects[4] = self.surfaces[4].surface.get_rect(topleft = fn.lerp2d(np.add(self.pos, (-600, -600*self.tan)), self.pos, 1-self.coef))
            """ for i in range(3):
                z = (45*i if i != 0 else 45)
                if self.angles[i] + (-z/fps if i%2 == 0 else z/fps) > (-z*2 if i%2 == 0 else z*2):
                    self.angles[i] += (-z/fps if i%2 == 0 else z/fps)
                else:
                    self.angles[i] = (-z*2 if i%2 == 0 else z*2) """
            if self.angles[0] - 45/fps > -90:
                self.angles[0] -= 45/fps
            else:
                self.angles[0] = -90
            if self.angles[1] + 45/fps < 90:
                self.angles[1] += 45/fps
            else:   
                self.angles[1] = 90
            if self.angles[2] - 90/fps > -180:
                self.angles[2] -= 90/fps
            else:
                self.angles[2] = -180
            if self.text_alpha - 255/fps > 0:
                self.text_alpha -= 255/fps
            else:
                self.text_alpha = 0
            if self.text_alpha1 - 255/fps > 0:
                self.text_alpha1 -= 255/fps
            else:
                self.text_alpha1 = 0
            if self.back_alpha - 255/fps > 0:
                self.back_alpha -= 255/fps
            else:
                self.back_alpha = 0
            self.surfaces[1].set_alpha(self.back_alpha)
            self.card_no_text.set_alpha(self.text_alpha)
            self.pin_no_text.set_alpha(self.text_alpha1)

        if self.coef == 1:
            if self.state < 2:
                self.state += 1
                self.coef = 0
        if self.state != 3:
            if self.angles[0] + 45/fps < 0:
                self.angles[0] += 45/fps
            else:
                self.angles[0] = 0

            if self.angles[1] - 45/fps > 0:
                self.angles[1] -= 45/fps
            else:
                self.angles[1] = 0  

        if self.angles[0] == 0:    
            if self.alpha - 100/fps > 0:
                self.alpha -= 100/fps
            else:
                self.alpha = 0
            self.surfaces[0].set_alpha(self.alpha)
        
        if self.state == 2:
            if self.numsellect:
                if self.numsellect1:
                    if self.text_alpha + 255/fps < 255:
                        self.text_alpha += 255/fps
                    else:
                        self.text_alpha = 255
                        self.numsellect1 = False
                else:
                    if self.text_alpha - 255/fps > 0:
                        self.text_alpha -= 255/fps
                    else:
                        self.text_alpha = 0
                        self.numsellect1 = True
            else:
                if self.text_alpha + 100/fps < 255:
                    self.text_alpha += 100/fps
                else:
                    self.text_alpha = 255
            if self.pinsellect:
                if self.pinsellect1:
                    if self.text_alpha1 + 255/fps < 255:
                        self.text_alpha1 += 255/fps
                    else:
                        self.text_alpha1 = 255
                        self.pinsellect1 = False
                else:
                    if self.text_alpha1 - 255/fps > 0:
                        self.text_alpha1 -= 255/fps
                    else:
                        self.text_alpha1 = 0
                        self.pinsellect1 = True
            else:
                if self.text_alpha1 + 100/fps < 255:
                    self.text_alpha1 += 100/fps
                else:
                    self.text_alpha1 = 255
            self.card_no_text.set_alpha(self.text_alpha)
            self.pin_no_text.set_alpha(self.text_alpha1)

    def draw(self, surface):
        surface.blit(self.surfaces[0].surface, (0,0))
        surface.blit(self.surfaces[1].surface, self.rects[1])
        surface.blit(pg.transform.rotate(self.surfaces[2].surface, self.angles[0]), self.rects[2])
        surface.blit(pg.transform.rotate(self.surfaces[3].surface, self.angles[1]), self.rects[3])
        surface.blit(pg.transform.rotate(self.surfaces[4].surface, self.angles[2]), self.rects[4])
        surface.blit(self.card_no_text, self.card_no_rect)
        surface.blit(self.pin_no_text, self.pin_no_rect)

    def mouse_down(self, position):
        if self.button1.collide(position):
            pg.quit()
            exit()
        if self.button.collide(position):
            if self.count == 1:
                isgo = False
                info = []
                for dat in self.database:
                    if self.card_no == dat[0]:
                        info = dat
                        isgo = True
                        self.count = 0
                        break
                if isgo:
                    if self.pin == info[1]:
                        self.state = 3
                        self.coef = 0
                        self.count = 0
                    else:
                        self.pin = ''
                        self.tbtext1 = 'Wrong Pin No'
                        self.surfaces[2].surface.blit(self.textbox1, (10,55))
                        self.tbtext_surf1 = fn.text(self.tbtext1, 'black', 30)
                        self.surfaces[2].surface.blit(self.tbtext_surf1, (15,61))
                        self.pinsellect = True
                        self.count = 0
                else:
                    self.card_no = ''
                    self.pin = ''
                    self.tbtext = 'Invalid Card No'
                    self.tbtext1 = ' '
                    self.surfaces[2].surface.blit(self.textbox, (10,10))
                    self.tbtext_surf = fn.text(self.tbtext, 'black', 30)
                    self.surfaces[2].surface.blit(self.tbtext_surf, (15,16))
                    self.surfaces[2].surface.blit(self.textbox1, (10,55))
                    self.tbtext_surf1 = fn.text(self.tbtext1, 'black', 30)
                    self.surfaces[2].surface.blit(self.tbtext_surf1, (15,61))
                    self.numsellect = True
                    self.count = 0
        if self.textrect.collidepoint(position):
            self.numsellect = True
        else:
            self.numsellect = False
        if self.textrect1.collidepoint(position):
            self.pinsellect = True
        else:
            self.pinsellect = False
    
    def mouse_up(self, position):
        self.count = 1

    def key_down(self, key, unicode):
        if self.numsellect:
            try:
                if key == pg.K_BACKSPACE:
                    if len(self.card_no) > 0:
                        self.card_no = self.card_no[:-1]
                        if len(self.card_no) > 4:
                            self.tbtext = self.card_no[:4]
                            for i in range(len(self.card_no)//4):
                                self.tbtext += " " + self.card_no[(i+1)*4:(i+1)*4+4]
                        else:
                            self.tbtext = self.card_no
                else:
                    k = int(unicode)
                    if len(self.card_no) < 16:
                        self.card_no += unicode
                        if len(self.card_no) > 4:
                            self.tbtext = self.card_no[:4]
                            for i in range(len(self.card_no)//4):
                                self.tbtext += " " + self.card_no[(i+1)*4:(i+1)*4+4]
                        else:
                            self.tbtext = self.card_no
                self.surfaces[2].surface.blit(self.textbox, (10,10))
                self.tbtext_surf = fn.text(self.tbtext, 'black', 30)
                self.surfaces[2].surface.blit(self.tbtext_surf, (15,16))
            except:
                pass
        if self.pinsellect:
            try:
                if key == pg.K_BACKSPACE:
                    if len(self.pin) > 0:
                        self.pin = self.pin[:-1]
                else:
                    res = int(unicode)
                    if len(self.pin) < 16:
                        self.pin += str(res)
                if len(self.pin) > 0:
                    self.tbtext1 = '*'*len(self.pin)
                else:
                    self.tbtext1 = ' '
                self.surfaces[2].surface.blit(self.textbox1, (10,55))
                self.tbtext_surf1 = fn.text(self.tbtext1, 'black', 30)
                self.surfaces[2].surface.blit(self.tbtext_surf1, (15,61))
            except:
                pass

class Textbox:
    def __init__(self, size, position):
        self.surface = pg.surface.Surface(size)
        self.surface.fill('white')
        self.content = ''
        self.rect = self.surface.get_rect(midleft = position)
        self.issellect = False
        self.size = size
    def update(self, fps):
        if self.issellect:
            self.surface.fill((100, 255, 255))
        else:
            self.surface.fill('white')
        if len(self.content) > 0:
            self.text_surf = fn.text('$' + '{:,}'.format(float(self.content)), (0, 0, 0), 35)
            self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
            self.surface.blit(self.text_surf, self.text_rect)
        if len(self.content) < 1:
            self.content = '0'
    def collide(self, position):
        if self.rect.collidepoint(position):
            self.issellect = True
        else:
            self.issellect = False
    def draw(self, surface, position):
        rect = self.surface.get_rect(midleft = position)
        surface.blit(self.surface, rect)
    def key_down(self, key, unicode):
        if self.issellect:
            if key == pg.K_BACKSPACE:
                if len(self.content) > 0:
                    self.content = self.content[:-1]
            else:
                try:
                    if self.content.count('.'):
                        res = str(int(unicode))
                    else:
                        res = '.' if unicode == '.' else str(int(unicode))
                    self.content += res
                except:
                    pass

class Textbox1:
    def __init__(self, size, position):
        self.surface = pg.surface.Surface(size)
        self.surface.fill('white')
        self.content = ''
        self.rect = self.surface.get_rect(midleft = position)
        self.issellect = False
        self.size = size
        self.content1 = ''
    def update(self, fps):
        if self.issellect:
            self.surface.fill((100, 255, 255))
        else:
            self.surface.fill('white')
        if len(self.content) > 0:
            if len(self.content) > 4:
                self.content1 = self.content[:4]
                for i in range(len(self.content)//4):
                    self.content1 += " " + self.content[(i+1)*4:(i+1)*4+4]
            else:
                self.content1 = self.content
            self.text_surf = fn.text(self.content1, (0, 0, 0), 35)
            self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
            self.surface.blit(self.text_surf, self.text_rect)
        else:
            self.text_surf = fn.text(' ', (0, 0, 0), 35)
            self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
            self.surface.blit(self.text_surf, self.text_rect)
    def collide(self, position):
        if self.rect.collidepoint(position):
            self.issellect = True
        else:
            self.issellect = False
    def draw(self, surface, position):
        rect = self.surface.get_rect(midleft = position)
        surface.blit(self.surface, rect)
    def key_down(self, key, unicode):
        if self.issellect:
            if key == pg.K_BACKSPACE:
                if len(self.content) > 0:
                    self.content = self.content[:-1]
            elif len(self.content) < 16:
                try:
                    if self.content.count('.'):
                        res = str(int(unicode))
                    else:
                        res = '.' if unicode == '.' else str(int(unicode))
                    self.content += res
                except:
                    pass

class Textbox2:
    def __init__(self, size, position):
        self.surface = pg.surface.Surface(size)
        self.surface.fill('white')
        self.content = ''
        self.content1 = ' '
        self.rect = self.surface.get_rect(midleft = position)
        self.issellect = False
        self.size = size
        self.ishide = True
    def update(self, fps):
        if self.issellect:
            self.surface.fill((100, 255, 255))
        else:
            self.surface.fill('white')
        if len(self.content) > 0:
            self.content1 = ' '
            if self.ishide:
                self.text_surf = fn.text('*'*len(self.content), (0, 0, 0), 35)
                self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
                self.surface.blit(self.text_surf, self.text_rect)
            else:
                self.text_surf = fn.text(self.content, (0, 0, 0), 35)
                self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
                self.surface.blit(self.text_surf, self.text_rect)
        else:
            self.text_surf = fn.text(self.content1, (0, 0, 0), 35)
            self.text_rect = self.text_surf.get_rect(center = np.divide(self.size, 2))
            self.surface.blit(self.text_surf, self.text_rect)
    def collide(self, position):
        if self.rect.collidepoint(position):
            self.issellect = True
        else:
            self.issellect = False
    def draw(self, surface, position):
        rect = self.surface.get_rect(midleft = position)
        surface.blit(self.surface, rect)
    def key_down(self, key, unicode):
        if self.issellect:
            if key == pg.K_BACKSPACE:
                if len(self.content) > 0:
                    self.content = self.content[:-1]
            else:
                try:
                    res = str(int(unicode))
                    self.content += res
                except:
                    pass
    def toogle(self):
        if self.ishide:
            self.ishide = False
        else:
            self.ishide = True

class Choices:
    isalive = True
    database = []
    with open('database.db', 'rb') as f:
        database = pk.load(f)
    info = []
    def __init__(self, size, screen_size, card_no):
        self.succ = False
        for item in Choices.database:
            if item[0] == card_no:
                Choices.info = item
                self.succ = True
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.choices = ['Deposit', 'Withdrawal', 'Balance', 'Transfer Fund', 'Mini Statement', 'Change Pin', 'Last 5 Transactions', 'Log Out']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text((str((i)*2+1) if i < 4 else str((i-4)*2+2)) + '. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text((str((i)*2+1) if i < 4 else str((i-4)*2+2)) + '. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        for i in range(4):
            self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + i*80)))
        for i in range(4):
            self.text_rects.append(self.text_surfaces[i+3].get_rect(midleft = (290, 100 + i*80)))
        for i in range(4):
            self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + i*80 + 5)))
        for i in range(4):
            self.text_rects.append(self.text_surfaces[i+3].get_rect(midleft = (290, 100 + i*80 + 5)))
        for i in range(16):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        if self.succ:
            self.username_surf = fn.text('User: ' + Choices.info[2], 'black', 32)
            self.username_surf1 = fn.text('User: ' + Choices.info[2], (100, 255, 180), 30)
            self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
            self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
            self.surface.blit(self.username_surf, self.username_rect)
            self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.surface1.set_alpha(0)
        self.isalive = True

        self.size = size
        self.screen_size = screen_size

        if self.succ:
            self.class_balance = Balance(size, screen_size, Choices.info)
            self.class_deposit = Deposit(size, screen_size, Choices.info)
            self.class_withdrawal = Withdrawal(size, screen_size, Choices.info)
            self.class_fund_transfer = Fund_transfer(size, screen_size, Choices.info)
            self.class_mini_statement = Mini_statement(size, screen_size, Choices.info)
            self.class_change_pin = Change_pin(size, screen_size, Choices.info)
            self.class_last_transaction = Last_transaction(size, screen_size, Choices.info)

            self.class_balance.isalive = False
            self.class_deposit.isalive = False
            self.class_withdrawal.isalive = False
            self.class_fund_transfer.isalive = False
            self.class_mini_statement.isalive = False
            self.class_change_pin.isalive = False
            self.class_last_transaction.isalive = False
        self.case = 0

    def update(self, fps):
        if self.state == 0:
            if self.alpha + 255/fps < 255:
                self.alpha += 255/fps
                self.surface1.set_alpha(self.alpha)
            else:
                self.surface1.set_alpha(255)
        self.class_balance.update(fps)
        self.class_deposit.update(fps)
        self.class_withdrawal.update(fps)
        self.class_fund_transfer.update(fps)
        self.class_mini_statement.update(fps)
        self.class_change_pin.update(fps)
        self.class_last_transaction.update(fps)
    def draw(self, surface):
        if Choices.isalive:
            surface.blit(self.surface1, self.rect)
        else:
            self.class_balance.draw(surface)
            self.class_deposit.draw(surface)
            self.class_withdrawal.draw(surface)
            self.class_fund_transfer.draw(surface)
            self.class_mini_statement.draw(surface)
            self.class_change_pin.draw(surface)
            self.class_last_transaction.draw(surface)
    def key_down(self, key, unicode):
        try:
            if Choices.isalive:
                res = int(unicode)
                match res:
                    case 1:
                        Choices.isalive = False
                        self.class_deposit.isalive = True
                        self.case = 1
                    case 2:
                        Choices.isalive = False
                        self.class_mini_statement.isalive = True
                        self.class_mini_statement.info = Choices.info
                        self.class_mini_statement.__init__(self.size, self.screen_size, Choices.info)
                        self.case = 2
                    case 3:
                        Choices.isalive = False
                        self.class_withdrawal.isalive = True
                        self.case = 3
                    case 4:
                        Choices.isalive = False
                        self.class_change_pin.isalive = True
                        self.case = 4
                    case 5:
                        Choices.isalive = False
                        self.class_balance.isalive = True
                        self.class_balance.info = Choices.info
                        self.class_balance.__init__(self.size, self.screen_size, Choices.info)
                        self.case = 5
                    case 6:
                        Choices.isalive = False
                        self.class_last_transaction.isalive = True
                        self.class_last_transaction.info = Choices.info
                        self.class_last_transaction.__init__(self.size, self.screen_size, Choices.info)
                        self.case = 6
                    case 7:
                        Choices.isalive = False
                        self.class_fund_transfer.isalive = True
                        self.case = 7
                    case 8:
                        self.isalive = False
                        self.case = 8
        except:
            pass
        if Choices.isalive == False:
            match self.case:
                case 1:
                    self.class_deposit.key_down(key, unicode)
                case 2:
                    self.class_mini_statement.key_down(key, unicode)
                case 3:
                    self.class_withdrawal.key_down(key, unicode)
                case 4:
                    self.class_change_pin.key_down(key, unicode)
                case 5:
                    self.class_balance.key_down(key, unicode)
                case 6:
                    self.class_last_transaction.key_down(key, unicode)
                case 7:
                    self.class_fund_transfer.key_down(key, unicode)
                case 8:
                    pass
    def mouse_down(self, position):
        self.class_deposit.mouse_down(position)
        self.class_withdrawal.mouse_down(position)
        self.class_fund_transfer.mouse_down(position)
        self.class_change_pin.mouse_down(position)

class Balance:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.choices = ['Balance: $' + '{:,}'.format(float(info[3])), 'Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(('1. ' if i==1 else '') + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(('1. ' if i==1 else '') + item, (100, 255, 180), 30))
        self.text_rects = []
        for i in range(2):
            self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + i*80)))
        for i in range(2):
            self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + i*80 + 5)))
        for i in range(4):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
    def update(self, fps):
        pass
    def draw(self, surface):
        if self.isalive:
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        try:
            if self.isalive:
                res = int(unicode)
                match res:
                    case 1:
                        self.isalive = False
                        Choices.isalive = True
        except:
            pass

class Deposit:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.text = 'Deposit amount:'
        self.text_surf = fn.text(self.text, 'black', 32)
        self.text_surf1 = fn.text(self.text, (100, 255, 180), 30)
        self.text_rect = self.text_surf1.get_rect(midleft = (20,100))
        self.text_rect1 = self.text_surf1.get_rect(midleft = (20,105))
        self.choices = ['Confirm', 'Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80 + 5)))
        for i in range(4):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.text_surf, self.text_rect)
        self.surface.blit(self.text_surf1, self.text_rect1)
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
        self.textbox = Textbox((280, 40), (400, 140))
    def update(self, fps):
        self.textbox.update(fps)
    def draw(self, surface):
        if self.isalive:
            self.textbox.draw(self.surface1, (300,100))
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        self.textbox.key_down(key, unicode)
        try:
            if self.isalive and self.textbox.issellect == False:
                res = int(unicode)
                match res:
                    case 1:
                        if float(self.textbox.content) > 0:
                            self.info[3] = str(float(self.info[3]) + float(self.textbox.content))
                            if len(self.info[4]) > 4:
                                self.info[4].pop(0)
                                self.info[4].append(str(time.asctime()) + ' | Deposit | $' + str(float(self.textbox.content)))
                            else:
                                self.info[4].append(str(time.asctime()) + ' | Deposit | $' + str(float(self.textbox.content)))
                            with open('database.db', 'rb') as f:
                                self.database = pk.load(f)
                            for i, info in enumerate(self.database):
                                if self.info[0] == info[0]:
                                    self.database[i] = self.info
                            with open('database.db', 'wb') as f:
                                pk.dump(self.database, f)
                            Choices.database = self.database
                            Choices.info = self.info
                            self.isalive = False
                            Choices.isalive = True
                            self.textbox.content = ''
                    case 2:
                        self.isalive = False
                        Choices.isalive = True
                        self.textbox.content = ''
        except:
            pass
    def mouse_down(self, position):
        self.textbox.collide(position)

class Withdrawal:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.text = 'Withdrawal amount:'
        self.text_surf = fn.text(self.text, 'black', 32)
        self.text_surf1 = fn.text(self.text, (100, 255, 180), 30)
        self.text_rect = self.text_surf1.get_rect(midleft = (20,100))
        self.text_rect1 = self.text_surf1.get_rect(midleft = (20,105))
        self.choices = ['Confirm', 'Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80 + 5)))
        for i in range(4):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.text_surf, self.text_rect)
        self.surface.blit(self.text_surf1, self.text_rect1)
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
        self.textbox = Textbox((280, 40), (400, 140))
    def update(self, fps):
        self.textbox.update(fps)
    def draw(self, surface):
        if self.isalive:
            self.textbox.draw(self.surface1, (300,100))
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        self.textbox.key_down(key, unicode)
        try:
            if self.isalive and self.textbox.issellect == False:
                res = int(unicode)
                match res:
                    case 1:
                        if float(self.textbox.content) > 0:
                            self.info[3] = str(float(self.info[3]) - float(self.textbox.content))
                            if len(self.info[4]) > 4:
                                self.info[4].pop(0)
                                self.info[4].append(str(time.asctime()) + ' | Withdraw | $' + str(float(self.textbox.content)))
                            else:
                                self.info[4].append(str(time.asctime()) + ' | Withdraw | $' + str(float(self.textbox.content)))
                            with open('database.db', 'rb') as f:
                                self.database = pk.load(f)
                            for i, info in enumerate(self.database):
                                if self.info[0] == info[0]:
                                    self.database[i] = self.info
                            with open('database.db', 'wb') as f:
                                pk.dump(self.database, f)
                            Choices.database = self.database
                            Choices.info = self.info
                            self.isalive = False
                            Choices.isalive = True
                            self.textbox.content = ''
                    case 2:
                        self.isalive = False
                        Choices.isalive = True
                        self.textbox.content = ''
        except:
            pass
    def mouse_down(self, position):
        self.textbox.collide(position)
    
class Fund_transfer:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.text = 'Target card no:'
        self.text1 = 'Amount:'
        self.text_surf = fn.text(self.text, 'black', 32)
        self.text_surf1 = fn.text(self.text, (100, 255, 180), 30)
        self.text_rect = self.text_surf1.get_rect(midleft = (20,100))
        self.text_rect1 = self.text_surf1.get_rect(midleft = (20,105))
        self.text_surf2 = fn.text(self.text1, 'black', 32)
        self.text_surf3 = fn.text(self.text1, (100, 255, 180), 30)
        self.text_rect2 = self.text_surf2.get_rect(midleft = (20,180))
        self.text_rect3 = self.text_surf2.get_rect(midleft = (20,185))
        self.choices = ['Confirm', 'Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80 + 5)))
        for i in range(4):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.text_surf, self.text_rect)
        self.surface.blit(self.text_surf1, self.text_rect1)
        self.surface.blit(self.text_surf2, self.text_rect2)
        self.surface.blit(self.text_surf3, self.text_rect3)
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
        self.textbox = Textbox1((340, 40), (360, 140))
        self.textbox1 = Textbox((340, 40), (360, 220))
        self.count = 1
    def update(self, fps):
        self.textbox.update(fps)
        self.textbox1.update(fps)
        if self.count == 0 and (self.textbox.issellect or self.textbox1.issellect):
            self.textbox.content = ''
            self.textbox1.content = ''
            self.count = 1
    def draw(self, surface):
        if self.isalive:
            self.textbox.draw(self.surface1, (260,100))
            self.textbox1.draw(self.surface1, (260,180))
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        self.textbox.key_down(key, unicode)
        if key == pg.K_ESCAPE:
            self.textbox1.key_down(key, unicode)
        else:
            if float(self.info[3]) < float(self.textbox1.content):
                self.textbox1.content = self.info[3]
            else:
                self.textbox1.key_down(key, unicode)
        try:
            if self.isalive and self.textbox.issellect == False and self.textbox1.issellect == False:
                res = int(unicode)
                match res:
                    case 1:
                        with open('database.db', 'rb') as f:
                            self.database = pk.load(f)
                        for i, info in enumerate(self.database):
                            if info[0] == self.textbox.content:
                                if float(self.textbox1.content) > 0 and float(self.textbox1.content) <= float(self.info[3]):
                                    self.info[3] = str(float(self.info[3]) - float(self.textbox1.content))
                                    self.database[i][3] = str(float(self.database[i][3]) + float(self.textbox1.content))
                                    if len(self.info[4]) > 4:
                                        self.info[5].pop(0)
                                        self.info[5].append(str(time.asctime()) + ' | ' + info[2] + ' | -$' + str(float(self.textbox1.content)))
                                    else:
                                        self.info[5].append(str(time.asctime()) + ' | ' + info[2] + ' | -$' + str(float(self.textbox1.content)))
                                    if len(self.info[4]) > 4:
                                        self.database[i][5].pop(0)
                                        self.database[i][5].append(str(time.asctime()) + ' | ' + info[2] + ' | +$' + str(float(self.textbox1.content)))
                                    else:
                                        self.database[i][5].append(str(time.asctime()) + ' | ' + info[2] + ' | +$' + str(float(self.textbox1.content)))
                                    for j, info1 in enumerate(self.database):
                                        if self.info[0] == info1[0]:
                                            self.database[j] = self.info
                                    with open('database.db', 'wb') as f:
                                        pk.dump(self.database, f)
                                    Choices.database = self.database
                                    Choices.info = self.info
                                    self.isalive = False
                                    Choices.isalive = True
                                    self.textbox.content = ''
                                    self.textbox1.content = ''
                                    self.count = 1
                                    break
                                elif float(self.textbox1.content) >= float(self.info[3]):
                                    self.database[i][3] = str(float(self.database[i][3]) + float(self.info[3]))
                                    if len(self.info[4]) > 4:
                                        self.info[5].pop(0)
                                        self.info[5].append(str(time.asctime()) + ' | ' + info[2] + ' | -$' + str(float(self.info[3])))
                                    else:
                                        self.info[5].append(str(time.asctime()) + ' | ' + info[2] + ' | -$' + str(float(self.info[3])))
                                    if len(self.info[4]) > 4:
                                        self.database[i][5].pop(0)
                                        self.database[i][5].append(str(time.asctime()) + ' | ' + self.database[i][2] + ' | +$' + str(float(self.info[3])))
                                    else:
                                        self.database[i][5].append(str(time.asctime()) + ' | ' + self.database[i][2] + ' | +$' + str(float(self.info[3])))
                                    self.info[3] = '0'
                                    for j, info1 in enumerate(self.database):
                                        if self.info[0] == info1[0]:
                                            self.database[j] = self.info
                                    with open('database.db', 'wb') as f:
                                        pk.dump(self.database, f)
                                    Choices.database = self.database
                                    Choices.info = self.info
                                    self.isalive = False
                                    Choices.isalive = True
                                    self.textbox.content = ''
                                    self.textbox1.content = ''
                                    self.count = 1
                                    break
                                else:
                                    self.isalive = False
                                    Choices.isalive = True
                                    self.textbox.content = ''
                                    self.textbox1.content = ''
                        if self.count == 1:
                            self.textbox.content = 'Invalid Card No'
                            self.count = 0
                    case 2:
                        self.isalive = False
                        Choices.isalive = True
                        self.textbox.content = ''
        except:
            pass
    def mouse_down(self, position):
        self.textbox.collide(position)
        self.textbox1.collide(position)


class Mini_statement:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.choices = ['Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text('1. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text('1. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))

        self.statement = ['Mini Statement:']
        for item in self.info[4]:
            self.statement.append(item)
        self.state_surf = []
        self.state_rect = []
        for text in self.statement:
            self.state_surf.append(fn.text(text, 'black', 28))
        for text in self.statement:
            self.state_surf.append(fn.text(text, (100, 255, 180), 26))
        for i in range(len(self.statement)):
            self.state_rect.append(self.state_surf[i].get_rect(midleft = (20, 100 + i*40)))
        for i in range(len(self.statement)):
            self.state_rect.append(self.state_surf[i].get_rect(midleft = (20, 100 + i*40 + 5)))

        for i in range(2):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        for i in range(len(self.state_surf)):
            self.surface.blit(self.state_surf[i], self.state_rect[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
    def update(self, fps):
        pass
    def draw(self, surface):
        if self.isalive:
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        try:
            if self.isalive:
                res = int(unicode)
                match res:
                    case 1:
                        self.isalive = False
                        Choices.isalive = True
        except:
            pass

class Change_pin:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.text = 'Old pin no:'
        self.text1 = 'New pin no:'
        self.text_surf = fn.text(self.text, 'black', 32)
        self.text_surf1 = fn.text(self.text, (100, 255, 180), 30)
        self.text_rect = self.text_surf1.get_rect(midleft = (20,100))
        self.text_rect1 = self.text_surf1.get_rect(midleft = (20,105))
        self.text_surf2 = fn.text(self.text1, 'black', 32)
        self.text_surf3 = fn.text(self.text1, (100, 255, 180), 30)
        self.text_rect2 = self.text_surf2.get_rect(midleft = (20,180))
        self.text_rect3 = self.text_surf2.get_rect(midleft = (20,185))
        self.choices = ['Confirm', 'Toggle show', 'Back',]
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text(str(i+1) + '. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 - 40)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5 - 40)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (290, 100 + 3*80 + 5)))
        for i in range(6):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.text_surf, self.text_rect)
        self.surface.blit(self.text_surf1, self.text_rect1)
        self.surface.blit(self.text_surf2, self.text_rect2)
        self.surface.blit(self.text_surf3, self.text_rect3)
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
        self.textbox = Textbox2((280, 40), (380, 140))
        self.textbox1 = Textbox2((280, 40), (380, 220))
    def update(self, fps):
        self.textbox.update(fps)
        self.textbox1.update(fps)
    def draw(self, surface):
        if self.isalive:
            self.textbox.draw(self.surface1, (280,100))
            self.textbox1.draw(self.surface1, (280,180))
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        self.textbox.key_down(key, unicode)
        self.textbox1.key_down(key, unicode)
        try:
            if self.isalive and self.textbox.issellect == False and self.textbox1.issellect == False:
                res = int(unicode)
                match res:
                    case 1:
                        with open('database.db', 'rb') as f:
                            self.database = pk.load(f)
                        if self.textbox.content == self.info[1] and len(self.textbox1.content) > 7:
                            self.info[1] = self.textbox1.content
                            for j, info in enumerate(self.database):
                                if self.info[0] == info[0]:
                                    self.database[j] = self.info
                            with open('database.db', 'wb') as f:
                                pk.dump(self.database, f)
                            Choices.database = self.database
                            Choices.info = self.info
                            self.isalive = False
                            Choices.isalive = True
                            self.textbox.content = ''
                            self.textbox1.content = ''
                        elif self.textbox.content == self.info[1]:
                            self.textbox1.content1 = "pin must > 7"
                            self.textbox1.content = ""
                        else:
                            self.textbox.content1 = 'Invalid pin'
                            self.textbox.content = ''

                    case 2:
                        self.textbox.toogle()
                        self.textbox1.toogle()
                    case 3:
                        self.isalive = False
                        Choices.isalive = True
                        self.textbox.content = ''
                        self.textbox1.content = ''
        except:
            pass
    def mouse_down(self, position):
        self.textbox.collide(position)
        self.textbox1.collide(position)

class Last_transaction:
    def __init__(self, size, screen_size, info):
        self.info = info
        self.surface = pg.surface.Surface(size)
        self.surface1 = pg.surface.Surface(np.add(size, 6))
        self.alpha = 0
        self.rect = self.surface.get_rect(center = np.divide(screen_size, 2))
        self.rect_poly = self.surface.get_rect(topleft = (0, 0))
        self.rect_poly1 = self.surface1.get_rect(topleft = (0, 0))
        pg.draw.rect(self.surface, (67, 56, 120), self.rect_poly, 0, 30)
        pg.draw.rect(self.surface1, (0, 255, 255), self.rect_poly1, 0, 30)
        self.state = 0
        self.choices = ['Back']
        self.text_surfaces = []
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text('1. ' + item, 'black', 32))
        for i, item in enumerate(self.choices):
            self.text_surfaces.append(fn.text('1. ' + item, (100, 255, 180), 30))
        self.text_rects = []
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80)))
        self.text_rects.append(self.text_surfaces[i].get_rect(midleft = (20, 100 + 3*80 + 5)))

        self.statement = ['Last 5 transaction:']
        for item in self.info[5]:
            self.statement.append(item)
        self.state_surf = []
        self.state_rect = []
        for text in self.statement:
            self.state_surf.append(fn.text(text, 'black', 28))
        for text in self.statement:
            self.state_surf.append(fn.text(text, (100, 255, 180), 26))
        for i in range(len(self.statement)):
            self.state_rect.append(self.state_surf[i].get_rect(midleft = (20, 100 + i*40)))
        for i in range(len(self.statement)):
            self.state_rect.append(self.state_surf[i].get_rect(midleft = (20, 100 + i*40 + 5)))

        for i in range(2):
            self.surface.blit(self.text_surfaces[i], self.text_rects[i])
        for i in range(len(self.state_surf)):
            self.surface.blit(self.state_surf[i], self.state_rect[i])
        self.username_surf = fn.text('User: ' + self.info[2], 'black', 32)
        self.username_surf1 = fn.text('User: ' + self.info[2], (100, 255, 180), 30)
        self.username_rect = self.username_surf1.get_rect(center = (300, 30))        
        self.username_rect1 = self.username_surf1.get_rect(center = (300, 30 + 5))
        self.surface.blit(self.username_surf, self.username_rect)
        self.surface.blit(self.username_surf1, self.username_rect1)
        self.surface1.blit(self.surface, (3,3))
        self.isalive = True
    def update(self, fps):
        pass
    def draw(self, surface):
        if self.isalive:
            surface.blit(self.surface1, self.rect)
    def key_down(self, key, unicode):
        try:
            if self.isalive:
                res = int(unicode)
                match res:
                    case 1:
                        self.isalive = False
                        Choices.isalive = True
        except:
            pass


