import pickle as pk

default = [
    ['0000111122223333', '1234567890', 'Jhoniel', '1200', [], []],
    ['4444555566667777', '0987654321', 'Ken', '3200', [], []]
]

with open('database.db', 'wb') as f:
    pk.dump(default, f)




