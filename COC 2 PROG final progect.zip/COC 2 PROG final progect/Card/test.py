import pickle as pk

with open('database.db', 'rb') as f:
    l = pk.load(f)

print(l)


