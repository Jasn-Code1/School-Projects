import pickle as pk

with open('database.db', 'rb') as f:
    l = pk.load(f)

with open('database.db', 'wb') as f:
    pk.dump(l, f)


for n in l:
    print(n)

