import math as m
import numpy as np
import pygame as pg

pg.init()
pg.font.init()

def text(text, color, size):
    font = pg.font.Font("Grosball.otf", size)
    font.set_italic(True)
    surf = font.render(text, True, color)
    return surf

def lerp2d(a,b,t):
    return [a[0]*(1-t)+b[0]*t,a[1]*(1-t)+b[1]*t]

def bcurve3(p,p1,p2,t):
    p3=lerp2d(p,p1,t)
    p4=lerp2d(p1,p2,t)
    p5=lerp2d(p3,p4,t)
    return p5

def bcurve4(p,p1,p2,p3,t):
    p4=lerp2d(p,p1,t)
    p5=lerp2d(p1,p2,t)
    p6=lerp2d(p2,p3,t)
    p7=lerp2d(p4,p5,t)
    p8=lerp2d(p5,p6,t)
    p9=lerp2d(p7,p8,t)
    return p9


