import pygame as pg
import numpy as np
import math as m
import random as rand
import Module
from sys import exit

pg.init()

screen = pg.display.set_mode((800,500))
width, height = screen.get_size()
clock = pg.time.Clock()

card = Module.Card((400,250), (450,250), (240, 193, 225), 10)
choices = []

running = True
count = 0
while running:
    fps = clock.get_fps()
    fps = fps if fps != 0 else 60
    
    screen.fill("black")
    if card.state != 3 or card.coef != 1:
        if card.state == 1:
            count = 0
        for e in pg.event.get():
            if e.type == pg.KEYDOWN:
                if e.key == pg.K_ESCAPE:
                    running = False
                card.key_down(e.key, e.unicode)
            if e.type == pg.MOUSEBUTTONDOWN:
                pos = e.pos
                card.mouse_down(pos)
            if e.type == pg.MOUSEBUTTONUP:
                pos = e.pos
                card.mouse_up(pos)
            if e.type == pg.QUIT:
                running = False

        card.update(fps)
        card.draw(screen)
    else:
        if count == 0:
            choices = Module.Choices((600,400), (width, height), card.card_no)
            count += 1

        for e in pg.event.get():
            if e.type == pg.KEYDOWN:
                if e.key == pg.K_ESCAPE:
                    running = False
                choices.key_down(e.key, e.unicode)
            if e.type == pg.MOUSEBUTTONDOWN:
                pos = e.pos 
                choices.mouse_down(pos)
            if e.type == pg.QUIT:
                running = False

        choices.update(fps)
        choices.draw(screen)

        if choices.isalive == False:
            card.state = 0
            card.coef = 0
            card.card_no = ''
            card.tbtext = ''
            card.pin = ''
            card.tbtext = ''
            card.numsellect = True
            card.pinsellect = True
            card.key_down(pg.K_BACKSPACE, ' ')
            card.database = choices.database   

    clock.tick(60)
    pg.display.flip()
pg.quit()
exit()




